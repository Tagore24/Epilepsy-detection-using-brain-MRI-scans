import os

import torch
from flask import Flask, redirect, render_template, request, url_for
from PIL import Image
from torchvision import transforms

from cnn_model import CNN  # Import your CNN model

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = "static/uploads"  # Set upload folder
# Load the trained model
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = CNN()
model.load_state_dict(torch.load('cnn_model.pth', map_location=device))
model.to(device)
model.eval()

# Define image preprocessing
transform = transforms.Compose([
    transforms.Resize((150, 150)),
    transforms.ToTensor(),
    transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return "No file uploaded", 400
    file = request.files['file']
    if file.filename == '':
        return "No file selected", 400

    if file:
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(filepath)  # Save the uploaded file to the specific location

        # Load and preprocess the image
        img = Image.open(filepath).convert('RGB')
        img = transform(img).unsqueeze(0).to(device)

        # Predict
        with torch.no_grad():
            output = model(img)
            prediction = "Yes" if output.item() > 0.5 else "No"

        return render_template('result.html', prediction=prediction, filepath=filepath)

if __name__ == '__main__':
    app.run(debug=True)
